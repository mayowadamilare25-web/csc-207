#include <iostream>
using namespace std;

int main() {
    long long number;

    cout << "Enter an integer: ";
    
    // Check if the user actually typed a valid number
    if (!(cin >> number)) {
        cout << "Error: That is not a valid integer." << endl;
        return 1;
    }

    if (number % 2 == 0) {
        cout << number << " is Even." << endl;
    } else {
        cout << number << " is Odd." << endl;
    }

    return 0;
}
